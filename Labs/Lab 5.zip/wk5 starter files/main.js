
// starter code for week 5 of pui lab


function addNewList() {
    alert('hello world alert!');
    console.log('hello world console');
}

